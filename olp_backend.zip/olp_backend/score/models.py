from django.db import models
from django.core.validators import MinValueValidator
from django.contrib.auth.models import User

from module.models import Module


class Score(models.Model):
    student_id = models.ForeignKey(
        User,
        on_delete = models.CASCADE
    )
    assessment_id = models.ForeignKey(
        'assessment.Assessment',
        on_delete = models.CASCADE
    )
    marks_obtained = models.IntegerField(
        default = 0,
        validators = [MinValueValidator(0)]
    )
