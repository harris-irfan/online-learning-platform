from django.db import models

from course.models import Course

MODULE_TYPES = (
    ("content", "content"),
    ("video", "video"),
    ("assessment", "assessment"),
)

class Module(models.Model):
    course = models.ForeignKey(
        'course.Course',
        on_delete = models.CASCADE
    )
    title = models.CharField(max_length = 200)
    type = models.CharField(max_length=10, choices=MODULE_TYPES)
    order = models.IntegerField()
    next_module = models.ForeignKey(
        'module.Module',
        null = True,
        on_delete = models.SET_NULL,
        related_name = '+'
    )
    prev_module = models.ForeignKey(
        'module.Module',
        null = True,
        on_delete = models.SET_NULL,
        related_name = '+'
    )

    def save(self, update_order):
        if update_order:
            if not self.course.first_module:
                self.order = 1
                super(Module, self).save()
                course = Course.objects.get(id=self.course.id)
                course.first_module = self
                course.last_module = self
                course.save()
            else:
                self.order = self.course.last_module.order + 1
                self.prev_module = self.course.last_module
                self.prev_module.next_module = self
                self.course.last_module = self
                super(Module, self).save()
                super(Module, self.prev_module).save()
                self.course.save()
        else:
            super(Module, self).save()

    def delete(self):
        super(Module, self).delete()
        if self.is_first_module():
            if self.is_last_module():
                self.course.first_module = None
                self.course.last_module = None
            else:
                self.course.first_module = self.next_module
                self.next_module.prev_module = None
                self.next_module.save(update_order=False)
            self.course.save()
        else:
            self.prev_module.next_module = self.next_module
            self.prev_module.save(update_order=False)
            if self.is_last_module():
                self.course.last_module = self.prev_module
                self.course.save()
            else:
                self.next_module.prev_module=self.prev_module
                self.next_module.save(update_order=False)

    def is_first_module(self):
        if not self.prev_module:
            return True
        return False

    def is_last_module(self):
        if not self.next_module:
            return True
        return False
