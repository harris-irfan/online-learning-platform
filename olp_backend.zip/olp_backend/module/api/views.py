from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from django.core import serializers
from django.http import HttpResponse

import os

from module.models import Module
from content.models import Content
from course.models import Course
from enrollment.models import Enrollment

@api_view(['GET',])
@permission_classes((IsAuthenticated, ))
def module_view(request):
    data = {}
    if 'module_id' in request.GET.keys():
        course = Module.objects.get(pk=request.GET['module_id']).course
        if request.user.is_staff or Enrollment.objects.filter(course = course, student = request.user).exists():
            module_queryset = Module.objects.filter(pk=request.GET['module_id'])
            data = serializers.serialize('json', module_queryset)
            return HttpResponse(data, content_type="application/json")
    elif request.user.is_staff or Enrollment.objects.filter(course = request.GET['course_id'], student = request.user).exists():
        module_queryset = Module.objects.filter(course=request.GET['course_id'])
        data = serializers.serialize('json', module_queryset)
        return HttpResponse(data, content_type="application/json")
    else:
        data['response_code'] = 403
        data['response_msg'] = 'You do not have permission to perform this action.'
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_module_view(request):
    data = {}
    module = Module.objects.get(id = request.GET['module_id'])
    if module.type == 'Content':
        content = Content.objects.get(module_ptr_id = request.GET['module_id'])
        content_path = content.html_path
        os.remove(content_path)
    module.delete()
    data['response'] = 'successfully deleted module'
    return Response(data)
