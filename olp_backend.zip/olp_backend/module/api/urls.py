from django.urls import path, include
from module.api.views import(
    module_view,
    delete_module_view,
)

app_name = 'module'

urlpatterns = [
    path('', module_view, name='view_modules'),
    path('delete/', delete_module_view, name='delete_module')
]
