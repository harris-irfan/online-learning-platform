from django.db import models


class Question(models.Model):
    text = models.CharField(max_length=1000)
    assessment = models.ForeignKey(
        'assessment.Assessment',
        on_delete = models.CASCADE
    )

    @property
    def choices(self):
        return self.choice_set.all()

    def __str__(self):
        return self.text
