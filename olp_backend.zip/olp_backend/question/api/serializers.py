from rest_framework import serializers

from question.models import Question
from assessment.models import Assessment
from choice.api.serializers import ChoiceSerializerForAdmin, ChoiceSerializerForStudent


class QuestionSerializerForAdmin(serializers.ModelSerializer):
    choices = ChoiceSerializerForAdmin(many=True, required=False)
    class Meta:
        model = Question
        fields = ['id', 'text', 'choices']

    def save(self, assessment_id):
        question = Question(
            text = self.validated_data['text'],
            )
        question.assessment = Assessment.objects.get(id = assessment_id)
        question.save()
        return question



class QuestionSerializerForStudent(serializers.ModelSerializer):
    choices = ChoiceSerializerForStudent(many=True, required=False)
    class Meta:
        model = Question
        fields = ['id', 'text', 'choices']
