from django.urls import path, include
from question.api.views import(
    QuestionView,
    question_view,
    add_question_view,
    delete_question_view
)

app_name = 'question'

urlpatterns = [
        path('', QuestionView.as_view({'get': 'list'}), name='questions'),
        path('add/', add_question_view, name='add_question'),
        path('delete/', delete_question_view, name='delete_question')
]
