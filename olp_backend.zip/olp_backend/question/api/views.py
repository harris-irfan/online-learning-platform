from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from question.models import Question
from module.models import Module
from question.api.serializers import QuestionSerializerForAdmin, QuestionSerializerForStudent
from choice.models import Choice
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.core import serializers
from django.http import HttpResponse
from itertools import chain
from certification.models import Certification
from enrollment.models import Enrollment
from assessment.models import Assessment
from django.db import models


class QuestionView(viewsets.ModelViewSet):
    # serializer_class = QuestionSerializer
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.request.user.is_staff:
            return QuestionSerializerForAdmin
        else:
            return QuestionSerializerForStudent

    def get_queryset(self):
        course_id = Module.objects.get(pk=self.request.query_params.get('assessment_id')).course_id
        if self.request.user.is_staff or Enrollment.objects.filter(course = course_id, student = self.request.user.id).exists():
            assessment_id = self.request.query_params.get('assessment_id')
            queryset = Question.objects.filter(assessment=assessment_id)
            return queryset

@api_view(['POST',])
@permission_classes((IsAdminUser, ))
def add_question_view(request):
    data = {}
    serializer = QuestionSerializerForAdmin(data=request.data)
    if serializer.is_valid():
        assessment_id = request.GET['assessment_id']
        question = serializer.save(assessment_id)
        assessment = Assessment.objects.get(module_ptr_id = assessment_id)
        assessment.total_marks += 1
        assessment.save(update_order=False)
        data['response_code'] = 00
        data['response_msg'] = 'successfully added a question'
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_question_view(request):
    data = {}
    assessment_id = Question.objects.get(id = request.GET['question_id']).assessment.module_ptr_id
    Question.objects.get(id = request.GET['question_id']).delete()
    assessment = Assessment.objects.get(module_ptr_id = assessment_id)
    assessment.total_marks -= 1
    assessment.save(update_order=False)
    data['response'] = 'successfully deleted question'
    return Response(data)


@api_view(['GET',])
def question_view(request):
    data = {}
    if Question.objects.filter(course_id=request.GET['course_id']).exists():
        question_queryset = Question.objects.filter(course_id=request.GET['course_id'])
        questions = [question.id for question in question_queryset]
        choice_queryset = Choice.objects.filter(question__in = question_queryset)
        both = list(chain(question_queryset, choice_queryset))
        data = serializers.serialize('json', both)
        return HttpResponse(data, content_type="application/json")
    else:
        data['response'] = 'Course not found'
        return Response(data)


# @api_view(['POST',])
# def submit_view(request):
#     data = {}
#     if Certification.is_elligible_for_certification(request):
#         enrollment = Enrollment.objects.get(course_id=request.GET['course_id'], student_id=request.user.id)
#         enrollment_id = enrollment.id
#         certification = Certification.create(enrollment)
#         #data['credential_id'] = certification.id
#         data['credential_id'] = Certification.objects.get(enrollment_id = enrollment_id).id
#     else:
#         data['response'] = 'You are not elligible for the certification'
#     return Response(data)
