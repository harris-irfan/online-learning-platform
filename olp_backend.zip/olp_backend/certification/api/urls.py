from django.urls import path, include
from certification.api.views import certification_view

app_name = 'certification'

urlpatterns = [
    path('', certification_view, name='certification_view'),
]
