from rest_framework.decorators import api_view
from rest_framework.response import Response

from certification.models import Certification


@api_view(['GET'])
def certification_view(request):
    data = {}
    credential_id = request.GET['credential_id']
    certificate = Certification.objects.get(credential_id=credential_id)
    student_full_name = certificate.enrollment.student.first_name + ' ' + certificate.enrollment.student.last_name
    course_id = certificate.enrollment.course.id
    course_name = certificate.enrollment.course.name
    data['response_code'] = '00'
    data['student_full_name'] = student_full_name
    data['course_id'] = course_id
    data['course_name'] = course_name
    return Response(data)
