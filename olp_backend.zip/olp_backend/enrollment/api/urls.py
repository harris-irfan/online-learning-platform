# from django.urls import path, include
# from enrollment.api.views import(
#     enrollment_view,
# )
#
# app_name = 'enrollment'
#
# urlpatterns = [
#         path('', enrollment_view, name='enrollments'),
# ]
