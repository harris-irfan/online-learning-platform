from rest_framework import serializers

from content.models import Content

from course.models import Course

class ContentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Content
        fields = ['title', 'type']

    def save(self, html_path, course_id):
        content = Content(
            title = self.validated_data['title'],
            type = self.validated_data['type'],
            html_path = html_path,
            )
        content.course = Course.objects.get(id = course_id)
        content.save(update_order=True)
        return content
