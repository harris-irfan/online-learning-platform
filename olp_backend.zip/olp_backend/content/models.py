from django.db import models

from module.models import Module


class Content(Module):
    html_path = models.CharField(max_length = 1000)
