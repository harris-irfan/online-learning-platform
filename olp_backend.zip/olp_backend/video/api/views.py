from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from django.http import HttpResponse

from .serializers import VideoSerializer
from django.core import serializers

from video.models import Video
from enrollment.models import Enrollment
from course.models import Course
from module.models import Module

@api_view(['GET',])
@permission_classes((IsAuthenticated, ))
def video_view(request):
    data = {}
    course = Module.objects.get(pk=request.GET['module_id']).course
    if request.user.is_staff or Enrollment.objects.filter(course = course, student = request.user).exists():
        video = Video.objects.get(module_ptr_id=request.GET['module_id'])
        data['url'] = video.url
    else:
        data['response'] = 'You do not have authorization to view this video'
    return Response(data)

@api_view(['POST', ])
@permission_classes((IsAdminUser, ))
def add_video_view(request):
    data = {}
    serializer = VideoSerializer(data=request.data)
    if serializer.is_valid():
        video = serializer.save(request.GET['course_id'])
        data['response_code'] = 00
        data['response_msg'] = 'successfully added a video'
        data['video_url'] = video.url
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_video_view(request):
    data = {}
    Video.objects.get(id = request.GET['video_id']).delete()
    data['response'] = 'successfully deleted video'
    return Response(data)
