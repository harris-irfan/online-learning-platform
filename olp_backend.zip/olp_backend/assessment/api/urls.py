from django.urls import path, include
from assessment.api.views import(
    assessment_view,
    add_assessment_view,
    delete_assessment_view,
    attempt_assessment_view,
    submit_assessment_view
)

app_name = 'assessment'

urlpatterns = [
    path('', assessment_view, name='view_assessment'),
    path('attempt/', attempt_assessment_view, name='attempt_assessment'),
    path('add/', add_assessment_view, name='add_assessment'),
    path('delete/', delete_assessment_view, name='delete_assessment'),
    path('submit/', submit_assessment_view, name='submit_assessment')
]
