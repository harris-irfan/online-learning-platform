from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from django.http import HttpResponse

from .serializers import AssessmentSerializer
from question.api.serializers import QuestionSerializerForAdmin

from course.models import Course
from assessment.models import Assessment
from question.models import Question
from certification.models import Certification
from enrollment.models import Enrollment
from module.models import Module
from choice.models import Choice
from django.core import serializers
from itertools import chain
from assessment.api.utils import calculate_score, calculate_percentage

import uuid

@api_view(['GET'])
def assessment_view(request):
    data = {}
    course = Module.objects.get(pk=request.GET['module_id']).course
    if request.user.is_staff or Enrollment.objects.filter(course = course, student = request.user).exists():
        assessment = Assessment.objects.filter(module_ptr_id=request.GET['module_id'])
        data = serializers.serialize('json', assessment)
        return HttpResponse(data, content_type="application/json")
    else:
        data['response'] = 'You do not have authorization to view this video'
        return Response(data)


@api_view(['POST',])
@permission_classes((IsAdminUser, ))
def add_assessment_view(request):
    data = {}
    serializer = AssessmentSerializer(data=request.data)
    if serializer.is_valid():
        assessment = serializer.save(request.GET['course_id'])
        data['response_code'] = 00
        data['response_msg'] = 'successfully added an assessment'
        data['assessment_type'] = assessment.type
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_assessment_view(request):
    data = {}
    Assessment.objects.get(id = request.GET['assessment_id']).delete()
    data['response'] = 'successfully deleted assessment'
    return Response(data)


@api_view(['GET',])
@permission_classes((IsAuthenticated, ))
def attempt_assessment_view(request):
    # data = {}
    # course_id = Module.objects.get(pk=request.GET['module_id']).course_id
    # if request.user.is_staff or Enrollment.objects.filter(course_id=course_id, student_id = request.user.id).exists():
    #     if Question.objects.filter(assessment=request.GET['module_id']).exists():
    #         question_queryset = Question.objects.filter(assessment=request.GET['module_id'])
    #         choice_queryset = Choice.objects.filter(question__in = question_queryset)
    #         both = list(chain(question_queryset, choice_queryset))
    #         data = serializers.serialize('json', both)
    #         return HttpResponse(data, content_type="application/json")
    #     else:
    #         return Response([])
    # else:
    #         data['response'] = 'You do not have authorization to attempt this assessment'
    #         return Response(data)

    # data = {}
    # course_id = Module.objects.get(pk=request.GET['module_id']).course_id
    # if request.user.is_staff or Enrollment.objects.filter(course_id=course_id, student_id = request.user.id).exists():
    #     if Question.objects.filter(assessment=request.GET['module_id']).exists():
    #         MCQs = []
    #         questions = Question.objects.filter(assessment=request.GET['module_id'])
    #         for question in questions:
    #             choices = Choice.objects.filter(question = question)
    #             MCQs.append(MCQ(question, choices))
    #             # data = serializers.serialize('json', MCQs)
    #             # return HttpResponse(data, content_type="application/json")
    #             return HttpResponse(MCQs, content_type="application/json")
    #     else:
    #         return Response([])
    # else:
    #         data['response'] = 'You do not have authorization to attempt this assessment'
    #         return Response(data)

    data = {}
    course_id = Module.objects.get(pk=request.GET['module_id']).course_id
    if request.user.is_staff or Enrollment.objects.filter(course_id=course_id, student_id = request.user.id).exists():
        if Question.objects.filter(assessment=request.GET['module_id']).exists():
            question_queryset = Question.objects.filter(assessment=request.GET['module_id'])
            # data = serializers.serialize('json', question_queryset)
            serializer = QuestionSerializerForAdmin(question_queryset[0])
            serializer.data
            return HttpResponse(serializer.data, content_type="application/json")
        else:
            return Response([])
    else:
            data['response'] = 'You do not have authorization to attempt this assessment'
            return Response(data)

@api_view(['POST',])
@permission_classes((IsAuthenticated, ))
def submit_assessment_view(request):
    data = {}
    module = Module.objects.get(id=request.GET['assessment_id'])
    course = module.course
    assessment = Assessment.objects.get(module_ptr_id = request.GET['assessment_id'])
    if request.user.is_staff or Enrollment.objects.filter(course = course, student = request.user).exists():
        choices = []
        for choice_id in request.data:
            if choice_id:
                choices.append(Choice.objects.get(id = choice_id))
        earned_score = calculate_score(choices)
        total_score = assessment.total_marks
        weightage = assessment.weightage
        earned_percentage = calculate_percentage(earned_score, total_score, weightage)
        enrollment = Enrollment.objects.get(course = course, student = request.user)
        enrollment.percentage_earned += earned_percentage
        enrollment.save()
        enrollment_id = enrollment.id
        if enrollment.percentage_earned >= course.passing_percentage:
            credential_id = uuid.uuid1().hex
            certification = Certification.create(enrollment, credential_id)
            data['response_code'] = '00'
            data['response'] = 'elligible for certification'
            data['earned_score'] = earned_score
            data['earned_percentage'] = enrollment.percentage_earned
            data['credential_id'] = credential_id
            return Response(data)
        else:
            data['response_code'] = '01'
            data['response'] = 'not elligible for certification'
            data['earned_score'] = earned_score
            data['earned_percentage'] = enrollment.percentage_earned
            return Response(data)
    else:
        data['response'] = 'Failure'
        return Response(data)
