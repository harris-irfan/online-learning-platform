from rest_framework import serializers

from assessment.models import Assessment

from course.models import Course

class AssessmentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Assessment
        fields = ['title', 'type', 'assessment_type', 'weightage']

    def save(self, course_id):
        assessment = Assessment(
            title = self.validated_data['title'],
            type = self.validated_data['type'],
            assessment_type = self.validated_data['assessment_type'],
            total_marks = 0,
            weightage = self.validated_data['weightage']
            )
        assessment.course = Course.objects.get(id = course_id)
        assessment.save(update_order=True)
        return assessment
