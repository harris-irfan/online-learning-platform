from django.contrib import admin

from .models import Assessment


class AssessmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'total_marks', 'weightage', 'course_id')

admin.site.register(Assessment, AssessmentAdmin)
