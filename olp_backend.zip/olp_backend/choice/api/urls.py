from django.urls import path, include
from choice.api.views import(
    add_choice_view,
    delete_choice_view
)

app_name = 'choice'

urlpatterns = [
        path('add/', add_choice_view, name='add_choice'),
        path('delete/', delete_choice_view, name='delete_choice')
]
