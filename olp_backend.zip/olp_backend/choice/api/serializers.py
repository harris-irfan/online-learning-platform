from rest_framework import serializers
from django.core import serializers as core_serializers

from choice.models import Choice
from question.models import Question

class ChoiceSerializerForAdmin(serializers.ModelSerializer):
    class Meta:
        model = Choice
        fields = ['id', 'text', 'is_correct', 'question']
        read_only_fields = ('question', )

    def save(self, question_id):
        choice = Choice(
            text = self.validated_data['text'],
            is_correct = self.validated_data['is_correct']
            )
        choice.question = Question.objects.get(id = question_id)
        choice.save()
        return choice

class ChoiceSerializerForStudent(serializers.ModelSerializer):
    class Meta:
        model = Choice
        fields = ['id', 'text', 'question']
        read_only_fields = ('question', )
