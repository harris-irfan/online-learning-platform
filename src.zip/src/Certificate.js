import React, { Component } from 'react';

class Certificate extends Component {

  constructor(props){
    super(props)

    this.state = {
      full_name: this.props.location.state.full_name,
      course_id: this.props.location.state.course_id,
      course_name: this.props.location.state.course_name
    }
  }

  render() {
    return (
      <div style={{'text-align': 'center', 'vertical-align': 'middle', 'line-height': '90px', 'color':'white', 'margin':'20px'}}>
        <h2> To Whom it may concern </h2>
        <h3> This is to certify that {this.state.full_name} has successfully completed the course of {this.state.course_name} ({this.state.course_id})</h3>
      </div>
    )
  }
}

export default  Certificate
