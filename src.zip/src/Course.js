import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import ReactPlayer from 'react-player'
import Header from './Header'
import ModuleModal from './ModuleModal'

class Course extends Component{

  constructor(props){
    super(props)

    this.state = {
      modal: false,
      moduleList: [],
      selected_module: null,
      is_enrolled: false,
      is_admin: localStorage.getItem('user_type') === 'admin'
    }

    var course = JSON.parse(localStorage.getItem('course'));

    if (course === null) {
      localStorage.setItem('course', JSON.stringify(this.props.location.state.course))
      this.state.course = this.props.location.state.course
    }
    else {
      this.state.course = course
    }
  }


  componentWillMount(){
    this.populateUserEnrollmentStatus(this.state.course.id)
    this.refreshList()
  }

  populateUserEnrollmentStatus = (id) => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/courses/verify_enrollment/?course_id='+id
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      if(data.response === 'Enrolled') {
        console.log(data)
        self.setState({is_enrolled: true})
      }
    })
  }

  refreshList = () => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/course_modules/?course_id='+this.state.course.id
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      self.setState({moduleList: data})
      console.log(data)
    })
  };

  viewItem = (item) => {
    this.setState({selected_module: item})
  };

  deleteItem = (id) => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/course_modules/delete/?module_id='+id
    fetch(url, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log(data)
      self.refreshList()
    })
  };

  renderItems = () => {
    return this.state.moduleList.map(item => (
      <li
        key={item.pk}
        className="list-group-item d-flex justify-content-between align-items-center"
      >
        <div>
          <span
            className={`todo-title mr-2`}
            style = {{fontWeight: 'bold'}}
            title={item.fields.title}
          >
            {item.fields.title}
            <br/>
          </span>
          {item.fields.type.toUpperCase()}
        </div>
        <span>
          <button onClick={() => this.viewItem(item)} className="btn btn-secondary mr-2"> View </button>
          {this.state.is_admin ? (
              <button onClick={() => this.deleteItem(item.pk)} className="btn btn-danger"> Delete </button>
          ): null}

        </span>
      </li>
    ));
  };

  handleAddModule = () => {
    this.setState({modal: !this.state.modal });
  };

  toggle = () => {
    this.setState({ modal: !this.state.modal });
  };

  render(){
    return(
      <div style={{'background-color': '#2E4158'}}>
        <Header/>
        {this.state.is_enrolled || this.state.is_admin ? (
        <div style={{'background-color': '#2E4158'}}>
        <div className="CourseDetails">
          <h5> Course Details</h5>
          <p>Id: {this.state.course.id}</p>
          <p>Name: {this.state.course.name}</p>
          <p>Description: {this.state.course.description}</p>
          <p>Duration: {this.state.course.duration}</p>
          <p>Passing Percentage: {this.state.course.passing_percentage}</p>
        </div>
        <div className="Modules">
          <main>
            <h5 style={{color:'white', margin:'10px'}}>Modules</h5>
              {localStorage.getItem('user_type') === 'admin' ? (
                <div>
                  <button onClick={this.handleAddModule} className="btn btn-primary">Add Module</button>
                </div>
                ): null}
              <ul className="list-group list-group-flush">
                <div className="List_item">
                  {this.renderItems()}
                </div>
              </ul>
          </main>
          {this.state.modal ? (
            <ModuleModal
              toggle={this.toggle}
              course_id={this.state.course.id}
              refreshList={this.refreshList}
            />
          ) : null}
          {this.state.selected_module ? (
            <Redirect push to={{
              pathname: '/'+this.state.selected_module.fields.type,
              state: {
                module: this.state.selected_module,
                goToPreviousModule: this.goToPreviousModule,
                goToNextModule: this.goToNextModule
              }
            }}/>
          ) : null}
        </div>
        </div>
      ): <h3 style={{color:'white'}}> Please get yourself enrolled in the course to view </h3>}
      </div>
    )
  }
}

export default Course
