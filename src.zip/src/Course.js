import React, { Component } from 'react';

class Course extends Component{

  constructor(details){
    super();

    this.state = details

    this.handleClick.bind(this);
  }
}
