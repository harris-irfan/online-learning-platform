import React, { Component } from 'react';
import Header from './Header'
import ModuleModal from './ModuleModal'

class Course extends Component{

  constructor(props){
    super(props)

    this.state = {
      modal: false,
      course: this.props.location.state.course,
      moduleList: []
    }
  }

  componentWillMount(){
    console.log(this.state.course)
    // this.refreshList()
    console.log('refreshList')
    console.log(this.state.id)
  }

  refreshList = () => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/course_modules/?course_id='+this.state.course.id
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      self.setState({moduleList: data})
      console.log(data)
    })
  };

  renderItems = () => {
    return this.state.moduleList.map(item => (
      <li
        key={item.id}
        className="list-group-item d-flex justify-content-between align-items-center"
      >
      <span
        className={`todo-title mr-2`}
        title={item.title}
      >
        {item.title}
      </span>
        <span>
          <button onClick={() => this.viewItem(item)} className="btn btn-secondary mr-2"> View </button>
          <button onClick={() => this.deleteItem(item.id)} className="btn btn-danger"> Delete </button>
        </span>
      </li>
    ));
  };

  handleAddModule = () => {
    this.setState({modal: !this.state.modal });
  };

  toggle = () => {
    this.setState({ modal: !this.state.modal });
  };

  render(){
    return(
      <div>
        <Header/>
        <div className="CourseDetails">
          <h5> Course Details</h5>
          <p>Id: {this.state.course.id}</p>
          <p>Name: {this.state.course.name}</p>
          <p>Description: {this.state.course.description}</p>
          <p>Duration: {this.state.course.duration}</p>
          <p>Passing Percentage: {this.state.course.passing_percentage}</p>
        </div>
        <div className="Modules">
          <main>
            <h6 style={{color:'white', padding:'5px'}}>Modules</h6>
            <div>
              <div>
                <div>
                  <div>
                    <button onClick={this.handleAddModule} className="btn btn-primary">Add Module</button>
                  </div>
                  <ul className="list-group list-group-flush">
                    <div className="List_item">
                      {this.renderItems()}
                    </div>
                  </ul>
                </div>
              </div>
            </div>
          </main>
          {this.state.modal ? (
            <ModuleModal
              toggle={this.toggle}
              course_id={this.state.course.id}
            />
          ) : null}
        </div>
      </div>
    )
  }
}

export default Course
