import React, { Component } from 'react';
import Modal from './Modal'
import Header from './Header'

class Course extends Component{

  constructor(props){
    super(props)

    this.state = {
      modal: false,
      course: this.props.location.state.course,
      module_list: []
    }
  }

  componentWillMount(){
    console.log(this.state.course)
    this.refreshList()
    console.log('refreshList')
    console.log(this.state.id)
  }

  refreshList = () => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/course_modules/?course_id='+this.state.course.id
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      self.setState({module_list: data})
      console.log(data)
    })
  }

  render(){
    return(
      <div>
        <Header/>
        <div className="CourseDetails">
          <h5> Course Details</h5>
          <p>Id: {this.state.course.id}</p>
          <p>Name: {this.state.course.name}</p>
          <p>Description: {this.state.course.description}</p>
          <p>Duration: {this.state.course.duration}</p>
          <p>Passing Percentage: {this.state.course.passing_percentage}</p>
        </div>
      </div>
    )
  }
}

export default Course
