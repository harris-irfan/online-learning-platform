import React, { Component } from "react";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input
} from "reactstrap";

export default class VideoModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      title: '',
      url: '',
      course_id: this.props.course_id
    }
  }

  handleChange = e => {
    let { name, value } = e.target;
    if (name === 'title') {
      this.setState({ title: value });
    }
    else {
      this.setState({ url: value });
    }
  }

  onSave = () => {
    this.props.toggle();

    const self = this

    let url = 'http://localhost:8000/api/course_modules/video/add/?course_id='+this.state.course_id

    fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth'),
      },
      body: JSON.stringify({
        title: this.state.title,
        url: this.state.url,
        type: "video"
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log(data)
      self.props.refreshList()
    })

  }

  render() {
    const { toggle } = this.props;
    return (
      <Modal isOpen={true} toggle={toggle} className="ModuleModal">
        <ModalHeader toggle={toggle} className="ModuleModalHeader"> Add Video </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
            <Label for="title">Title</Label>
            <Input
              type="text"
              name="title"
              value={this.state.title}
              onChange={this.handleChange}
              placeholder="Enter Title"
            />
            </FormGroup>
            <FormGroup>
              <Label for="title">Video Url</Label>
              <Input
                type="text"
                name="url"
                value={this.state.url}
                onChange={this.handleChange}
                placeholder="Enter Video Url"
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="success" onClick={() => this.onSave()}>
            Save
          </Button>
        </ModalFooter>
      </Modal>
      );
  }
}
