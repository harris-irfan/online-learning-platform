import React, { Component } from 'react'
import { Redirect } from 'react-router-dom';
import Logout from "./Logout"

export default class ModuleHeader extends Component {

  constructor(props){
    super(props)

    console.log(this.props)

    this.state = {
      current_module: this.props.current_module,
      goToModule: null
    }
  }

  goToModule = (direction) => {
    console.log('clicked on goto')
    const self = this
    if (direction === 'next') {
      var url = 'http://127.0.0.1:8000/api/course_modules/?module_id='+this.state.current_module.fields.next_module
    }
    else {
      var url = 'http://127.0.0.1:8000/api/course_modules/?module_id='+this.state.current_module.fields.prev_module
    }
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log(data[0])
      self.setState({goToModule: data[0]})
      // self.props.goToModule(data[0])
    })
  }

  goToNextModule = () => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/course_modules/?module_id='+this.state.current_module.fields.next_module
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      self.props.goToModule(data[0])
    })
  }

  render() {
    return (
      <div className="header">
        <h1>{this.props.current_module.fields.title}</h1>
        <div className="header-right">
        <button onClick={() => this.goToModule('previous')} className="btn btn-primary mr-2" disabled={!this.state.current_module.fields.prev_module}>Prev Module</button>
        <button onClick={() => this.goToModule('next')} className="btn btn-primary" disabled={!this.state.current_module.fields.next_module}>Next Module</button>
        </div>
        {this.state.goToModule ? (
          <Redirect push to={{
            pathname: '/'+this.state.goToModule.fields.type,
            state: {
              module: this.state.goToModule,
            }
          }}/>
        ) : null}
      </div>

    )
  }
}

// <h3 style={{'paddingLeft':'20px', 'paddingTop':'20px', color:'white'}}>{this.props.title}</h3>
