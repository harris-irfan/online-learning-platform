import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import Header from './Header'
import ModuleHeader from './ModuleHeader'
import AddQuestionModal from './AddQuestionModal'
import AddChoiceModal from './AddChoiceModal'
import ChoiceType from './ChoiceType'
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Form,
  FormGroup,
  Input
} from "reactstrap";

class Assessment extends Component{

  constructor(props){
    super(props)

    this.state = {
      modal: false,
      add_choice_modal:false,
      module: this.props.location.state.module,
      assessment: {},
      questionList: [],
      assessment_title: this.props.location.state.assessment_title,
      selected_question_id: null,
      view_choices_of_question_id: null,
      choiceOption: 'View',
      selectedChoiceIds: []
    }
  }

  componentWillMount() {

    const self = this
    let url = 'http://localhost:8000/api/course_modules/assessment/?module_id='+this.state.module.pk
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      }
    }).then(function(response){ return response.json(); })
      .then(function(data) {
        self.setState({assessment:data[0].fields})
        console.log('assessment')
        console.log(data)
      })

     this.refreshList()
  }

  incrementTotalMarks = () => {
    const assessment = { ...this.state.assessment, ['total_marks']: this.state.assessment.total_marks+1 };
    this.setState({ assessment:  assessment});
  }

  decrementTotlaMarks = () => {
    const assessment = { ...this.state.assessment, ['total_marks']: this.state.assessment.total_marks-1 };
    this.setState({ assessment:  assessment});
  }

  refreshList = () => {
    const self = this
    let url = 'http://localhost:8000/api/assessment/questions/?assessment_id='+this.state.module.pk
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log('***********************************************************')
      console.log(data)
      self.setState({questionList: data})
    })
  };

  viewChoices = (id) => {
    if (this.state.choiceOption === 'View') {
      this.setState({view_choices_of_question_id: id})
      this.setState({choiceOption: 'Collapse'})
    }
    else {
      if (id === this.state.view_choices_of_question_id) {
        this.setState({view_choices_of_question_id: null})
        this.setState({choiceOption: 'View'})
      }
      else {
        this.setState({view_choices_of_question_id: id})
        this.setState({choiceOption: 'Collapse'})
      }

    }
  };

  deleteItem = (id) => {
    const self = this
    let url = 'http://localhost:8000/api/assessment/questions/delete/?question_id='+id
    fetch(url, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log(data)
      self.refreshList()
      self.decrementTotlaMarks()
    })
  };

  handleAddChoice = (question_id) => {
    this.setState({ selected_question_id: question_id,
                    add_choice_modal: !this.state.add_choice_modal });
  }

  deleteChoice = (id) => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/question/choice/delete/?choice_id='+id
    fetch(url, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      }
    }).then(function(response){
        return response.json();
    }).then(function(data){
      console.log(data)
      self.refreshList()
      self.decrementTotlaMarks()
    })
  }

  handleCheckBoxInput = (choice_id) => {

    let index = this.state.selectedChoiceIds.indexOf(choice_id)
    if (index === -1) {
      this.state.selectedChoiceIds.push(choice_id)
    }
    else {
      this.state.selectedChoiceIds.splice(index, 1);
    }
        console.log(this.state.selectedChoiceIds)
  }

  renderChoices = (choices) => {
    return choices.map(choice => (
      <div>
        <li
          key={choice.id}
          className="list-group-item d-flex justify-content-between align-items-center"
          style = {{ borderBottomColor: 'black', borderBottomWidth: 1}}
        >
          <div>
            <span
              style = {{fontWeight: 'bold'}}
            >
            <div className="ListItem">
            <FormGroup check>
                <Input onClick={() => this.handleCheckBoxInput(choice.id)} type="checkbox" />{' '}
            </FormGroup>
              {choice.text}
              {localStorage.getItem('user_type') === 'admin' ? (
                <ChoiceType is_correct={choice.is_correct} />
              ): null}
            </div>
            </span>
          </div>
          {localStorage.getItem('user_type') === 'admin' ? (
            <span>
              <button onClick={() => this.deleteChoice(choice.id)} className="btn btn-danger"> Delete </button>
            </span>
            ): null
          }
        </li>
      </div>
    ));
  };

  renderItems = () => {
    return this.state.questionList.map(question => (
      <div>
        <li
          key={question.id}
          className="list-group-item d-flex justify-content-between align-items-center"
          style = {{ borderBottomColor: 'black', borderBottomWidth: 1}}
        >
          <div>
            <span
              className={`todo-title mr-2`}
              style = {{fontWeight: 'bold'}}
              title={question.text}
            >
              {question.text}
            </span>
          </div>
          <span>
            {localStorage.getItem('user_type') === 'admin' ? (
              <button onClick={() => this.handleAddChoice(question.id)} className="btn btn-primary mr-2"> Add Choice </button>
            ): null}
            { localStorage.getItem('user_type') === 'student' ? null
              :[this.state.view_choices_of_question_id === question.id ? (
                <button
                  onClick={() => this.viewChoices(question.id)}
                  className="btn btn-secondary mr-2"
                >
                  {this.state.choiceOption} Choices
                </button>
                ) :
                <button
                  onClick={() => this.viewChoices(question.id)}
                  className="btn btn-secondary mr-2"
                  disabled={question.choices.length === 0}
                  style={{width:'145px'}}
                >
                  View Choices
                </button>
               ]
            }
            {localStorage.getItem('user_type') === 'admin' ? (
              <button onClick={() => this.deleteItem(question.id)} className="btn btn-danger"> Delete </button>
            ): null}
          </span>
        </li>
        { localStorage.getItem('user_type') === 'student' ?
          this.renderChoices(question.choices)
          : [
              <div>
              {this.state.view_choices_of_question_id == question.id? (
                this.renderChoices(question.choices)
              ): null}
              </div>
            ]
        }
      </div>
    ));
  };

  handleAddQuestion = () => {
    this.setState({ modal: !this.state.modal });
  };

  toggle = () => {
    this.setState({ modal: !this.state.modal });
  };

  addChoiceToggle = () => {
    this.setState({ add_choice_modal: !this.state.add_choice_modal });
  }

  handleSubmitAssessment = () => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/course_modules/assessment/submit/?assessment_id='+this.state.module.pk
    fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
      body: JSON.stringify(this.state.selectedChoiceIds)
    }).then(function(response){
        return response.json();
    }).then(function(data){
      console.log(data)
      if (data.response_code === '00') {
        alert('Congratulations for completing this course. You can access your course certificate with the Credential ID: '+data.credential_id)
      }
    })
  }

  render(){
    return(
      <div>
        <Header/>
        <ModuleHeader
          current_module = {this.state.module}
          goToModule = {this.goToModule}
        />
        <div className="CourseDetails">
          <h5>Assessment Details</h5>
          <p>Type: {this.state.assessment.assessment_type}</p>
          <p>Total Marks: {this.state.assessment.total_marks}</p>
          <p>Weightage: {this.state.assessment.weightage}</p>
        </div>
        <div className="Modules">
          <main>
            <h6 style={{color:'white', padding:'5px'}}>Questions</h6>
            {localStorage.getItem('user_type') === 'admin' ? (
              <div>
                <button onClick={this.handleAddQuestion} className="btn btn-primary">Add Question</button>
              </div>
            ): null}
            <ul className="list-group list-group-flush">
              <div className="List_item">
                {this.renderItems()}
              </div>
            </ul>
          </main>
          <FormGroup check row>
              <Button onClick={() => this.handleSubmitAssessment()} style={{marginTop:'30px'}}>Submit</Button>
          </FormGroup>
        </div>
        {this.state.modal ? (
          <AddQuestionModal
            assessment_id = {this.state.module.pk}
            toggle={this.toggle}
            refreshList={this.refreshList}
            incrementTotalMarks={this.incrementTotalMarks}
          />
        ) : null}
        {this.state.add_choice_modal ? (
          <AddChoiceModal
            question_id = {this.state.selected_question_id}
            toggle={this.addChoiceToggle}
            refreshList={this.refreshList}
          />
        ) : null}
      </div>
    )
  }
}

export default Assessment
