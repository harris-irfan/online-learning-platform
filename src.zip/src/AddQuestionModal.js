import React, { Component } from "react";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input
} from "reactstrap";

export default class AddQuestionModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      assessment_id: this.props.assessment_id,
      question_text: '',
    }
  }

  handleChange = e => {
      this.setState({ question_text: e.target.value });
  }

  onSave = () => {
    this.props.toggle();

    const self = this

    let url = 'http://localhost:8000/api/assessment/questions/add/?assessment_id='+this.state.assessment_id

    console.log('url')
    console.log(url)

    fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth'),
      },
      body: JSON.stringify({
        text: this.state.question_text,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log('API response')
      console.log(data)
      self.props.refreshList()
      self.props.incrementTotalMarks()
    })
  }

  render() {
    const { toggle } = this.props;
    return (
      <Modal isOpen={true} toggle={toggle} className="ModuleModal">
        <ModalHeader toggle={toggle} className="ModuleModalHeader"> Add Question </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
            <Label for="question">Question</Label>
            <Input
              type="text"
              value={this.state.question_text}
              onChange={this.handleChange}
              placeholder="Enter Question"
            />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="success" onClick={() => this.onSave()}>
            Save
          </Button>
        </ModalFooter>
      </Modal>
      );
  };
}
