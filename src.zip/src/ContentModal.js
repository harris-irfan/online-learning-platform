import React, { Component } from "react";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input
} from "reactstrap";

export default class ContentModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      title: '',
      selected_html_file: '',
      course_id: ''
    }
  }

  handleAddContent = () => {
    this.setState({selected_module: 'Content'})
  }

  handleChange = e => {
    let { name, value } = e.target;
    this.setState({ title: value });
  }

  onSave = () => {
    this.toggle();
    // alert("save" + JSON.stringify(item));

    const self = this

    // url = 'http://localhost:8000/api/course_modules/content/upload/?course_id='+

    fetch('http://localhost:8000/api/course_modules/content/upload/?course_id=1', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
      body: JSON.stringify({
        file: this.state.selected_html_file,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      const response = data;
      console.log(response)
      self.refreshList()
    })

  }

  handleChangeFileInput = (e) => {
    this.setState({selected_html_file: e.target.files[0]})
  }

  render() {
    const { toggle } = this.props;
    return (
      <Modal isOpen={true} toggle={toggle} className="ModuleModal">
        <ModalHeader toggle={toggle} className="ModuleModalHeader"> Add Content </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
            <Label for="title">Title</Label>
            <Input
              type="text"
              name="title"
              value={this.state.title}
              onChange={this.handleChange}
              placeholder="Enter Title"
            />
            </FormGroup>
            <FormGroup>
              <Label for="title">Upload HTML File</Label>
              <Input type="file" name="file" id="exampleFile" onChange={this.handleChangeFileInput}/>
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="success" onClick={() => this.onSave()}>
            Save
          </Button>
        </ModalFooter>
      </Modal>
      );
  }
}
