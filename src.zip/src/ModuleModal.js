import React, { Component } from "react";
import ContentModal from './ContentModal';
import VideoModal from './VideoModal';
import AssessmentModal from './AssessmentModal';
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Form,
  FormGroup,
} from "reactstrap";

export default class ModuleModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selected_module: '',
      course_id: this.props.course_id
    };
  }

  handleAddContent = () => {
    this.setState({selected_module: 'Content'})
  }

  handleAddVideo = () => {
    this.setState({selected_module: 'Video'})
  }

  handleAddAssessment = () => {
    this.setState({selected_module: 'Assessment'})
  }

  render() {
    const { toggle } = this.props;
    console.log(this.props)
    console.log(this.props.refreshList)
    const { refreshList } = this.props.refreshList
    if (this.state.selected_module === '') {
      return (
        <Modal isOpen={true} toggle={toggle} className="ModuleModal">
          <ModalHeader toggle={toggle} className="ModuleModalHeader"> Add Module </ModalHeader>
          <ModalBody className="ModuleModalBody">
            <Form>
              <FormGroup>
                <div onClick={this.handleAddContent} className="ModuleModalOptions">
                  Content
                </div>
              </FormGroup>
              <FormGroup>
                <div onClick={this.handleAddVideo} className="ModuleModalOptions">
                  Video
                </div>
              </FormGroup>
              <FormGroup>
                <div onClick={this.handleAddAssessment} className="ModuleModalOptions">
                  Assessment
                </div>
              </FormGroup>
            </Form>
          </ModalBody>
        </Modal>
      );
    }
    else if (this.state.selected_module === 'Content') {
      return(
        <ContentModal
          toggle={toggle}
          course_id={this.state.course_id}
          refreshList = {this.props.refreshList}
        />
      );
    }
    else if (this.state.selected_module === 'Video') {
      return(
        <VideoModal
          toggle={toggle}
          course_id={this.state.course_id}
          refreshList = {this.props.refreshList}
        />
      )
    }
    else {
      return(
        <AssessmentModal
          toggle={toggle}
          course_id={this.state.course_id}
          refreshList = {this.props.refreshList}
        />
      );
    }
  }
}
