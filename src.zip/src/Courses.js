import React, { Component } from 'react';
import {Redirect} from 'react-router-dom';
import Modal from './Modal'
import Header from './Header'

class Courses extends Component{

  constructor(){
    super();

    this.state = {
      modal: false,
      activeItem: {
        id: "",
        name: "",
        description: "",
        duration: "",
        passing_percentage: ""
      },
      courseList: [],
      selected_course: ''
    }
  }

  componentWillMount(){
    this.refreshList()
  }

  refreshList = () => {
    const self = this
    fetch('http://127.0.0.1:8000/api/courses/', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      self.setState({courseList: data})
    })
  }

  renderItems = () => {
    return this.state.courseList.map(item => (
      <li
        key={item.id}
        className="list-group-item d-flex justify-content-between align-items-center"
      >
      <span
        className={`todo-title mr-2`}
        title={item.description}
      >
        {item.name}
      </span>
        <span>
          <button onClick={() => this.viewItem(item)} className="btn btn-secondary mr-2"> View </button>
          <button onClick={() => this.deleteItem(item.id)} className="btn btn-danger">Delete </button>
        </span>
      </li>
    ));
  };

  toggle = () => {
    this.setState({ modal: !this.state.modal });
  };

  handleSubmit = item => {
    this.toggle();
    alert("save" + JSON.stringify(item));

    const self = this

    fetch('http://127.0.0.1:8000/api/courses/add/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
      body: JSON.stringify({
        id: item.id,
        name: item.name,
        description: item.description,
        duration: item.duration,
        passing_percentage: item.passing_percentage,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      const response = data;
      console.log(response)
      self.refreshList()
    })
  };

  handleChange = e => {
    let { name, value } = e.target;
    const activeItem = { ...this.state.activeItem, [name]: value };
    this.setState({ activeItem });
  };

  createItem = () => {
    const item = { id: "", name: "", description: "", duration: "", passing_percentage: "" };
    this.setState({ activeItem: item, modal: !this.state.modal });
  };

  deleteItem = (id) => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/courses/delete/?course_id='+id
    fetch(url, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log(data)
      self.refreshList()
    })
  };

  viewItem = (course) => {
    this.setState({selected_course: course})
  }

  render() {
    if (this.state.selected_course === '') {
      return (
        <div className="Courses">
          <Header/>
          <main>
            <h3 style={{color:'white', padding:'5px'}}>Courses</h3>
            <div>
              <div>
                <div>
                  <div>
                    <button onClick={this.createItem} className="btn btn-primary">Add Course</button>
                  </div>
                  <ul className="list-group list-group-flush">
                    <div className="List_item">
                      {this.renderItems()}
                    </div>
                  </ul>
                </div>
              </div>
            </div>
          </main>
          {this.state.modal ? (
            <Modal
              activeItem={this.state.activeItem}
              toggle={this.toggle}
              onSave={this.handleSubmit}
            />
          ) : null}
        </div>
      );
    }
    else{
      let url = '/course_detail'
      let course = this.state.selected_course
      return(
        <Redirect to={{pathname: url,
                       state: {course: course}}}
        />
      )
    }
  }
}

export default Courses;
