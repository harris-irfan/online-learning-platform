import React, { Component } from 'react';
import {Redirect} from 'react-router-dom';
import Modal from './Modal'
import Header from './Header'

class Courses extends Component{

  constructor(){
    super();

    this.state = {
      modal: false,
      activeItem: {
        id: "",
        name: "",
        description: "",
        duration: "",
        passing_percentage: "",
        user_type: ''
      },
      courseList: [],
      selected_course: '',
      is_enrolled: false
    }
  }

  componentWillMount(){
    this.setState({user_type: localStorage.getItem('user_type')})
    this.refreshList()
  }


  refreshList = () => {
    const self = this
    fetch('http://127.0.0.1:8000/api/courses/', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      self.setState({courseList: data})
    })
  }

  enrollCourse = (id) => {
    let url = 'http://127.0.0.1:8000/api/courses/enrollment/?course_id='+id
    fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log(data)
      alert(data.response)
    })
  }

  renderItems = () => {
    return this.state.courseList.map(item => (
      <li
        key={item.id}
        className="list-group-item d-flex justify-content-between align-items-center"
      >
      <span
        className={`todo-title mr-2`}
        title={item.description}
      >
        {item.name}
      </span>
        <span>
          <button onClick={() => this.viewItem(item)} className="btn btn-secondary mr-2"> View </button>
          {this.state.user_type === 'admin' ?
            (<button onClick={() => this.deleteItem(item.id)} className="btn btn-danger">Delete </button>)
          : (<button onClick={() => this.enrollCourse(item.id)} className="btn btn-danger">Enroll </button>)}

        </span>
      </li>
    ));
  };

  toggle = () => {
    this.setState({ modal: !this.state.modal });
  };

  handleSubmit = item => {
    this.toggle();

    const self = this

    fetch('http://127.0.0.1:8000/api/courses/add/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
      body: JSON.stringify({
        id: item.id,
        name: item.name,
        description: item.description,
        duration: item.duration,
        passing_percentage: item.passing_percentage,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      const response = data;
      console.log(response)
      self.refreshList()
    })
  };

  handleChange = e => {
    let { name, value } = e.target;
    const activeItem = { ...this.state.activeItem, [name]: value };
    this.setState({ activeItem });
  };

  createItem = () => {
    const item = { id: "", name: "", description: "", duration: "", passing_percentage: "" };
    this.setState({ activeItem: item, modal: !this.state.modal });
  };

  deleteItem = (id) => {
    const self = this
    let url = 'http://127.0.0.1:8000/api/courses/delete/?course_id='+id
    fetch(url, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log(data)
      self.refreshList()
    })
  };

  viewItem = (course) => {
    this.setState({selected_course: course})
  }

  render() {
    if (this.state.selected_course === '') {
      return (
        <div className="Courses">
          <Header/>
          <main>
            <h3 style={{color:'white', padding:'5px'}}>Courses</h3>
              {localStorage.getItem('user_type') === 'admin' ?(
                <div>
                  <button onClick={this.createItem} className="btn btn-primary">Add Course</button>
                </div>
              ): null}
              <ul className="list-group list-group-flush">
                <div className="List_item">
                  {this.renderItems()}
                </div>
              </ul>
          </main>
          {this.state.modal ? (
            <Modal
              activeItem={this.state.activeItem}
              toggle={this.toggle}
              onSave={this.handleSubmit}
              refreshList={this.refreshList}
            />
          ) : null}
        </div>
      );
    }
    else{
      let url = '/course_detail'
      let course = this.state.selected_course
      return(
        <Redirect push to={{pathname: url,
                       state: {course: course}}}
        />
      )
    }
  }
}

export default Courses;
