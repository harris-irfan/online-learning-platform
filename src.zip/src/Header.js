import React, {Component} from "react";
import Logout from "./Logout"



export default class Header extends Component {

  constructor(props){
    super(props)
  }

  render () {
    return (
      <div className="header">
        <h3>Olp {this.props.userType}</h3>
        <div className="header-right">
          <Logout/>
        </div>
      </div>
    );
  }
}
