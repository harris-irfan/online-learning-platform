import React from "react";
import Logout from "./Logout"

function Header() {
  return (
    <div className="header">
      <h1>Olp Administration</h1>
      <div className="header-right">
        <Logout/>
      </div>
    </div>
  );
}
export default Header;
