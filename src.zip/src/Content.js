import React, { Component } from 'react';
import Header from './Header'
import ModuleHeader from './ModuleHeader'

class Content extends Component {
  constructor(props){
    super(props)

    this.state = {
      module: this.props.location.state.module,
      content_html: null
    }
  }

  componentWillMount() {
      var url = 'http://localhost:8000/api/course_modules/content/?module_id='+this.state.module.pk
      const self = this
      fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': localStorage.getItem('auth')
        }
      }).then(function(response){ return response.json(); })
      .then(function(data) {
          self.setState({content_html:data.html})
      })
  }

  render(){
    console.log(this.state.content_html)
    return(
      <div>
        <Header/>
        <ModuleHeader
          current_module = {this.state.module}
        />
        <div className="Content" dangerouslySetInnerHTML={{__html: this.state.content_html}}/>
      </div>
    )
  }
}

export default Content

// <h3 style={{'paddingLeft':'20px', 'paddingTop':'20px', color:'white'}}>{this.state.module.fields.title}</h3>
