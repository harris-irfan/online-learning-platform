import React, { Component } from 'react';
import {NavLink} from 'react-router-dom';

class Logout extends Component {

  handleClick = () => {

    let auth = 'Token ' + localStorage.getItem('auth_token')

    fetch('http://127.0.0.1:8000/api/account/rest-auth/logout/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': auth
      },
    }).then(function(response){return response.json();
    }).then(function(data) {
        localStorage.removeItem("auth_token");
      })
  }

  render() {
    return(
      <div>
        <NavLink exact activeClassName="active" to="/">
          Logout
        </NavLink>
      </div>
    )
  }
}

export default Logout;
