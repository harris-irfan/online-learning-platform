import React, { Component } from 'react';
import SignIn from './pages/Signin';
import {HashRouter as Router, Route, Redirect} from 'react-router-dom';

import history from './history';

class Logout extends Component {

  constructor(){
    super();

    this.state={
      is_logged_in: true
    };

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(){

    let auth = 'Token ' + localStorage.getItem('auth_token')

    var self = this

    fetch('http://127.0.0.1:8000/api/account/rest-auth/logout/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': auth
      },
    }).then(function(response){return response.json();
    }).then(function(data) {
        const response = data;
        localStorage.removeItem("auth_token");
        self.setState({is_logged_in: false});
      })
  }

  render() {
    if (this.state.is_logged_in){
      return(
        <div>
            <button className="FormField__Button" onClick={this.handleClick}>Logout</button>
        </div>
      )
    }
    else{
      return(
        <Redirect to="/" push={true}/>
      )
    }
  }
}

export default Logout;
