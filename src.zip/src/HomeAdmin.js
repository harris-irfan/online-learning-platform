import React, { Component } from 'react';

import Logout from './Logout'
import Course from './Course'

const courses = [
  {
    id: 1,
    name: "English",
    description: "English Course",
    duration: "1 week",
    passing_percentage: 50
  },
  {
    id: 2,
    name: "Urdu",
    description: "Urdu Course",
    duration: "1 week",
    passing_percentage: 50
  },
  {
    id: 3,
    name: "Math",
    description: "Math Course",
    duration: '1 week',
    passing_percentage: 50
  },
  {
    id: 4,
    name: "French",
    description: "French Course",
    duration: "1 week",
    passing_percentage: 50
  }
];

class HomeAdmin extends Component {

  constructor(props){
    super(props);

    this.state = {
      courseList: courses
    };

    this.handleClick.bind(this);
  }

  renderItems = () => {
    return this.state.courseList.map(item => (
      <li
        key={item.id}
        className="list-group-item d-flex justify-content-between align-items-center"
      >
      <span
        className={`todo-title mr-2`}
        title={item.description}
      >
        {item.name}
      </span>
        <span>
          <button className="btn btn-secondary mr-2"> Edit </button>
          <button className="btn btn-danger">Delete </button>
        </span>
      </li>
    ));
  };

  handleClick(){
    fetch('http://127.0.0.1:8000/api/courses/', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){ return response.json(); })
    .then(function(data) {
    const response = data;

    console.log(response)

    var courses = []

    for (let i=0; i<response.length; i++){
      let course = <Course details={response[0]}/>
      courses.push(course)
    }

    console.log(courses)

    })
  }

  // render() {
  //   return(
  //     <div>
  //       <div style={{float: 'right'}}>
  //         <Logout/>
  //       </div>
  //       <h1>Welcome Olp Admin</h1>
  //       <a onClick={this.handleClick} style={{cursor: 'pointer'}}>Courses</a>
  //     </div>
  //   )
  // }

  render() {
    return (
      <div>
      <main className="content">
        <h1 className="text-white text-uppercase text-center my-4">Courses</h1>
        <div className="row ">
          <div className="col-md-6 col-sm-10 mx-auto p-0">
            <div className="card p-3">
              <div className="">
                <button className="btn btn-primary">Add Course</button>
              </div>
              <ul className="list-group list-group-flush">
                {this.renderItems()}
              </ul>
            </div>
          </div>
        </div>
      </main>
      </div>
    );
  }



}

export default HomeAdmin;
