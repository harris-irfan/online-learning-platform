import React, { Component } from 'react';
import {NavLink} from 'react-router-dom';
import Header from './Header'

class HomeAdmin extends Component {

  render() {
    return(
      <div style={{'backgroundColor': '#66DAC7'}}>
        <Header/>
        <NavLink style={{padding:'10px'}} exact to="/courses">
          Courses
        </NavLink>
      </div>
    )
  }
}

export default HomeAdmin;
