import React, { Component } from 'react';
import './App.css';
import SignUp from './pages/Signup';
import SignIn from './pages/Signin';
import HomeAdmin from './HomeAdmin';
import HomeStudent from './HomeStudent';
import Courses from './Courses';
import Course from './Course';
import Video from './Video'
import Content from './Content'
import Assessment from './Assessment'
import Certification from './Certification'
import Certificate from './Certificate'
import {HashRouter as Router, Route} from 'react-router-dom';

class App extends Component {

  render() {
    return (
      <Router basename="/">
        <Route exact path="/" component={SignUp}></Route>
        <Route path="/signin" component={SignIn}></Route>
        <Route path="/homeadmin" component={HomeAdmin}></Route>
        <Route path="/homestudent" component={HomeStudent}></Route>
        <Route path="/courses" component={Courses}></Route>
        <Route path="/course_detail" component={Course}></Route>
        <Route path="/video" component={Video}></Route>
        <Route path="/content" component={Content}></Route>
        <Route path="/assessment" component={Assessment}></Route>
        <Route path="/certificates" component={Certification}></Route>
        <Route path="/certificate" component={Certificate}></Route>
      </Router>
    );
  }
}

export default App;

// <Route exact path="/course/:id" render={props => <Course {...props} /> } />
