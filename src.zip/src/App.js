import React, { Component } from 'react';
import './App.css';
import SignUp from './pages/Signup';
import SignIn from './pages/Signin';
import HomeAdmin from './HomeAdmin';
import HomeStudent from './HomeStudent';
import Courses from './Courses';
import Course from './Course';
import {HashRouter as Router, Route} from 'react-router-dom';

class App extends Component {

  render() {
    return (
      <Router basename="/">
        <Route exact path="/" component={SignUp}></Route>
        <Route path="/signin" component={SignIn}></Route>
        <Route path="/homeadmin" component={HomeAdmin}></Route>
        <Route path="/homestudent" component={HomeStudent}></Route>
        <Route path="/courses" component={Courses}></Route>
        <Route path="/course_detail" component={Course}></Route>
      </Router>
    );
  }
}

export default App;

// <Route exact path="/course/:id" render={props => <Course {...props} /> } />
