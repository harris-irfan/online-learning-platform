import React, { Component } from 'react';
import './App.css';
import SignUp from './pages/Signup';
import SignIn from './pages/Signin';
import {HashRouter as Router, Route} from 'react-router-dom';

class App extends Component {
  render() {
    return (
      <Router basename="/">
        <div className="App">
          <div className="App__Aside"></div>
          <div className="App__Form">
            <Route exact path="/" component={SignUp}></Route>
            <Route path="/signin" component={SignIn}></Route>
          </div>
        </div>
      </Router>
    );
  }
}

export default App;
