import React, { Component } from 'react';
import ReactPlayer from 'react-player'
import Header from './Header'
import ModuleHeader from './ModuleHeader'


class Video extends Component {
  constructor(props){
    super(props)
    this.state = {
      module: this.props.location.state.module,
      video_url: null
    }
  }

  componentWillMount() {
    var url = 'http://localhost:8000/api/course_modules/video/?module_id='+this.state.module.pk
    const self = this
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      }
    }).then(function(response){ return response.json(); })
    .then(function(data) {
        self.setState({video_url:data.url})
    })
  }

  render(){
    return(
      <div>
        <Header/>
        <ModuleHeader
          current_module = {this.state.module}
        />
        <div className="Video">
          <ReactPlayer url={this.state.video_url} playing controls />
        </div>
      </div>
    )
  }
}

export default Video
