import React, { Component } from 'react';

import Logout from './Logout'

class HomeStudent extends Component {

  render() {
    return(
      <div>
        <div style={{float: 'right'}}>
          <Logout/>
        </div>
        <h1>Welcome Olp Student</h1>
      </div>
    )
  }
}

export default HomeStudent;
