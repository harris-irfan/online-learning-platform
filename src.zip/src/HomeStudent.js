import React, { Component } from 'react';
import {NavLink} from 'react-router-dom';
import Header from './Header'

class HomeAdmin extends Component {

  render() {
    return(
      <div style={{'backgroundColor': '#66DAC7'}}>
        <Header userType="Student"/>
        <NavLink style={{padding:'10px', fontSize: '20px'}} exact to="/courses">
          Courses
        </NavLink>
      </div>
    )
  }
}

export default HomeAdmin;
