import React, { Component } from 'react';

export default class ChoiceType extends Component {
  constructor(props){
    super(props)
  }

  render() {
    return (
      <div>
        {this.props.is_correct ? (<p style={{'marginLeft':5}}> (Correct) </p> ): <p style={{'marginLeft':5}}> (Incorrect) </p>}
      </div>
    )
  }
}
