import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';

import {
  Button,
  Form,
  FormGroup,
  Input
} from "reactstrap";

class Certification extends Component {

  constructor(props) {
    super(props);
    this.state = {
      credential_id: '',
      certificate_found: false,
      certificate_full_name: '',
      certificate_course_id: '',
      certificate_course_name: '',
    };
  }

  handleSubmit = (e) => {
    e.preventDefault();
    self = this
    console.log(this.state.credential_id)
    let url = 'http://localhost:8000/api/certification/?credential_id='+this.state.credential_id
    fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      }
    }).then(function(response){ return response.json(); })
      .then(function(data) {
        console.log(data)
        if (data.response_code == '00') {
          self.setState({certificate_full_name: data.student_full_name})
          self.setState({certificate_course_id: data.course_id})
          self.setState({certificate_course_name: data.course_name})
          self.setState({certificate_found: true})
        }
        console.log(self.state)
      })
  }

  handleChange = (e) => {
    this.setState({
      credential_id: e.target.value
    });
  }

  render() {
    return (
      <div>
      {!this.state.certificate_found ? (
      <div className="FormCenter" style ={{paddingLeft: '30px', paddingTop: '20px'}}>
        <div className="FormTitle">
          Find your desired certificate
        </div>
        <form onSubmit={this.handleSubmit} className="FormFields">
          <div className="FormField">
            <label className="FormField__Label">Credential ID</label>
              <input className="FormField__Input" type="text" placeholder="Enter credential id" name="credential_id" value={this.state.credential_id} onChange={this.handleChange}/>
          </div>
          <div>
            <button className="FormField__Button mr-20" type="submit"> Show Certificate </button>
          </div>
        </form>
      </div>
    ):  <Redirect push to={{pathname: '/certificate',
                           state: {
                             full_name: this.state.certificate_full_name,
                             course_name: this.state.certificate_course_name,
                             course_id: this.state.certificate_course_id
                           }}}
        />}
    </div>
    )
  }
}

export default  Certification
