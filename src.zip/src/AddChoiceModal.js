import React, { Component } from "react";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input
} from "reactstrap";

export default class AddChoiceModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      question_id: this.props.question_id,
      choice_text: '',
      is_correct: false
    }
  }

  handleChange = e => {
    let { name, value } = e.target;
    if (e.target.type === "checkbox") {
      this.setState({is_correct: !this.state.is_correct});
    }
    else {
      this.setState({choice_text: value})
    }
  }

  onSave = () => {
    this.props.toggle();
    const self = this
    let url = 'http://127.0.0.1:8000/api/question/choice/add/?question_id='+this.state.question_id
    fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
      body: JSON.stringify({
        text: this.state.choice_text,
        is_correct: this.state.is_correct
      })
    }).then(function(response){
      return response.json();
    }).then(function(data) {
        console.log(data)
        self.props.refreshList()
    })
  };

  render() {
    const { toggle } = this.props;
    return (
      <Modal isOpen={true} toggle={toggle} className="ModuleModal">
        <ModalHeader toggle={toggle} className="ModuleModalHeader"> Add Choice </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
            <Label for="choice">Choice</Label>
            <Input
              type="text"
              name="choice"
              value={this.state.choice_text}
              onChange={this.handleChange}
              placeholder="Enter Choice"
            />
            </FormGroup>
            <FormGroup check>
              <Label for="is_correct">
                <Input
                  type="checkbox"
                  name="is_correct"
                  checked={this.state.is_correct}
                  onChange={this.handleChange}
                />
                Check this box if the choice you entered is the correct answer
              </Label>
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="success" onClick={() => this.onSave()}>
            Save
          </Button>
        </ModalFooter>
      </Modal>
      );
  };
}
