import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import HomeAdmin from '../HomeAdmin';
import HomeStudent from '../HomeStudent';

class SignIn extends Component {

  constructor() {
      super();

      this.state = {
          username: '',
          password: '',
          is_logged_in: false,
          user_type: ''
      };

      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
      this.postLoginAction = this.postLoginAction.bind(this);
  }

  postLoginAction(){

    let auth = 'Token ' + localStorage.getItem('auth_token')

    self = this

    fetch('http://127.0.0.1:8000/api/account/user_type/', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': auth
      },
    }).then(function(response){return response.json();})
      .then(function(data) {
        const response = data;
        console.log(response)
        self.setState({user_type: response.user_type})
      })
  }

  handleChange(e) {
      let target = e.target;
      let value = target.value
      let name = target.name;

      this.setState({
        [name]: value
      });
  }

  handleSubmit(e) {
    e.preventDefault();

    self = this

    fetch('http://127.0.0.1:8000/api/account/rest-auth/login/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: this.state.username,
        password: this.state.password,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
    const response = data;

    console.log(response)

    if (response.key){
      console.log(response.key)
      let auth_token = response.key
      localStorage.setItem('auth_token', auth_token)
      localStorage.setItem('auth', 'Token ' + auth_token)

      console.log(localStorage.getItem('auth_token'))
      self.setState({is_logged_in: true})
      self.postLoginAction()
    }
})
  }

  render() {
    if (!this.state.is_logged_in){
      return (
        <div className="FormCenter">
          <div className="FormTitle">
            Sign Up
          </div>
          <form onSubmit={this.handleSubmit} className="FormFields">
            <div className="FormField">
              <label className="FormField__Label">Username</label>
                <input type="text" name="username" value={this.state.username} onChange={this.handleChange}/>
            </div>
            <div className="FormField">
              <label className="FormField__Label">Password</label>
                <input type="password" name="password" value={this.state.password} onChange={this.handleChange}/>
            </div>
            <div className="FormField">
              <button className="FormField__Button mr-20" type="submit">Sign In</button> <Link to="/" className="FormField__Link">I don't have an account</Link>
            </div>
          </form>
        </div>
      )
    }
    else{
      if (this.state.user_type == 'admin'){
          console.log("rendering admin")
          return(
            <HomeAdmin/>
          )
      }
      else{
          return(
            <HomeStudent/>
          )
      }
    }
  }
}

export default SignIn;
