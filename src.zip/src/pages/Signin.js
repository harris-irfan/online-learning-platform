import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class SignIn extends Component {

  constructor() {
      super();

      this.state = {
          username: '',
          password: '',
      };

      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(e) {
      let target = e.target;
      let value = target.value
      let name = target.name;

      this.setState({
        [name]: value
      });
  }

  handleSubmit(e) {
    e.preventDefault();

    fetch('http://127.0.0.1:8000/api/account/rest-auth/login/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: this.state.username,
        password: this.state.password,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
    const response = data;

    console.log(response)

    if(response.response_code == '00'){
      console.log('success')
      // props.history.push()
    }
})
  }

  render() {
    return (
      <div className="FormCenter">
        <div className="FormTitle">
          Sign Up
        </div>
        <form onSubmit={this.handleSubmit} className="FormFields">
          <div className="FormField">
            <label className="FormField__Label">Username</label>
              <input type="text" name="username" value={this.state.username} onChange={this.handleChange}/>
          </div>
          <div className="FormField">
            <label className="FormField__Label">Password</label>
              <input type="password" name="password" value={this.state.password} onChange={this.handleChange}/>
          </div>
          <div className="FormField">
            <button className="FormField__Button mr-20" type="submit">Sign In</button> <Link to="/" className="FormField__Link">I don't have an account</Link>
          </div>
        </form>
      </div>
    )
  }
}

export default SignIn;
