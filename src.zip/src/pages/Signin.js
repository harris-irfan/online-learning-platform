import React, { Component } from 'react';
import { Link, Redirect, NavLink } from 'react-router-dom';

class SignIn extends Component {

  constructor() {
      super();

      this.state = {
          username: '',
          password: '',
          is_logged_in: false,
          user_type: ''
      };
  }

  postLoginAction = () => {

    const self = this

    fetch('http://127.0.0.1:8000/api/account/user_type/', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth')
      },
    }).then(function(response){return response.json();})
      .then(function(data) {
        console.log(data)
        self.setState({user_type: data.user_type})
        self.setState({is_logged_in: true})
      })
  }

  handleChange = (e) => {
      let target = e.target;
      let value = target.value
      let name = target.name;

      this.setState({
        [name]: value
      });
  }

  handleSubmit = (e) => {
    e.preventDefault();

    const self = this

    fetch('http://127.0.0.1:8000/api/account/rest-auth/login/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: this.state.username,
        password: this.state.password,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
    const response = data;

    console.log(response)

    if (response.key){
      console.log(response.key)
      let auth_token = response.key
      localStorage.setItem('auth', 'Token ' + auth_token)

      console.log(localStorage.getItem('auth_token'))
      self.postLoginAction()
    }
})
  }

  render() {
    if (!this.state.is_logged_in){
      return (
        <div className="App">
          <div className="App__Aside">
            <div className="welcome">
              <h5 style={{color:'#2E4158'}}>Welcome to the Online Learning Platform</h5>
            </div>
          </div>
          <div className="App__Form">
            <div className="PageSwitcher">
              <NavLink to="/signin" activeClassName="PageSwitcher__Item--Active" className="PageSwitcher__Item">Sign In</NavLink>
              <NavLink exact to="/" activeClassName="PageSwitcher__Item--Active" className="PageSwitcher__Item">Sign Up</NavLink>
            </div>
            <div className="FormCenter">
              <div className="FormTitle">
                Sign In
              </div>
              <form onSubmit={this.handleSubmit} className="FormFields">
                <div className="FormField">
                  <label className="FormField__Label">Username</label>
                    <input className="FormField__Input" type="text" placeholder="Enter your username" name="username" value={this.state.username} onChange={this.handleChange}/>
                </div>
                <div className="FormField">
                  <label className="FormField__Label">Password</label>
                    <input className="FormField__Input" type="password" placeholder="Enter your password" name="password" value={this.state.password} onChange={this.handleChange}/>
                </div>
                <div className="FormField">
                  <button className="FormField__Button mr-20" type="submit">Sign In</button> <Link to="/" className="FormField__Link">I don't have an account</Link>
                </div>
              </form>
            </div>
          </div>
        </div>
      )
    }
    else{
      if (this.state.user_type === "admin"){
        console.log('rendering admin')
        return(
          <Redirect to='/homeadmin' />
        )
      }
      else{
        console.log('rendering student')
        return(
          <Redirect to='/homestudent' />
        )
      }
    }
  }
}

export default SignIn;
