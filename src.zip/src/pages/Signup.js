import React, { Component } from 'react';
import { Link, Redirect, NavLink } from 'react-router-dom';

class SignUp extends Component {

  constructor(props) {
      super(props);

      this.state = {
          email: '',
          username: '',
          first_name: '',
          last_name: '',
          password: '',
          confirm_password: '',
          is_registered: false
      };
  }

  handleChange = (e) => {
      let target = e.target;
      let value = target.value
      let name = target.name;

      this.setState({
        [name]: value
      });
  }

  handleSubmit = (e) => {
    e.preventDefault();

    var self = this;

    console.log(this.state.email)
    console.log(this.state.username)
    console.log(this.state.first_name)
    console.log(this.state.last_name)
    console.log(this.state.password)
    console.log(this.state.confirm_password)

    fetch('http://127.0.0.1:8000/api/account/register/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: this.state.email,
        username: this.state.username,
        first_name: this.state.first_name,
        last_name: this.state.last_name,
        password: this.state.password,
        confirm_password: this.state.confirm_password,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {

    console.log(data)

    if(data.response_code === '00'){
        console.log('success')
        self.setState({is_registered: true})
        alert("You have succesfully registered. Please sign in to continue.")
    }
    })
  }

  render() {
    if (!this.state.is_registered)
    {
      return(
        <div className="App">
          <div className="App__Aside">
            <div className="welcome">
              <h5 style={{color:'#2E4158'}}>Welcome to the Online Learning Platform</h5>
            </div>
          </div>
          <div className="App__Form">
            <div className="PageSwitcher">
              <NavLink to="/signin" activeClassName="PageSwitcher__Item--Active" className="PageSwitcher__Item">Sign In</NavLink>
              <NavLink exact to="/" activeClassName="PageSwitcher__Item--Active" className="PageSwitcher__Item">Sign Up</NavLink>
            </div>
            <div className="FormCenter">
              <div className="FormTitle">
                Sign Up
              </div>
              <form onSubmit={this.handleSubmit} className="FormFields">
                <div className="FormField">
                  <label className="FormField__Label">Email</label>
                    <input className="FormField__Input" type="text" placeholder="Enter your email"  name="email" value={this.state.email} onChange={this.handleChange}/>
                </div>
                <div className="FormField">
                  <label className="FormField__Label">Username</label>
                    <input className="FormField__Input" type="text" placeholder="Enter your username" name="username" value={this.state.username} onChange={this.handleChange}/>
                </div>
                <div className="FormField">
                  <label className="FormField__Label">First Name</label>
                    <input className="FormField__Input" type="text" placeholder="Enter your first name" name="first_name" value={this.state.first_name} onChange={this.handleChange}/>
                </div>
                <div className="FormField">
                  <label className="FormField__Label">Last Name</label>
                    <input className="FormField__Input" type="text" placeholder="Enter your last name" name="last_name" value={this.state.last_name} onChange={this.handleChange}/>
                </div>
                <div className="FormField">
                  <label className="FormField__Label">Password</label>
                    <input className="FormField__Input" type="password" placeholder="Enter your password" name="password" value={this.state.password} onChange={this.handleChange}/>
                </div>
                <div className="FormField">
                  <label className="FormField__Label">Confirm Password</label>
                    <input className="FormField__Input" type="password" placeholder="Enter your password again" name="confirm_password" value={this.state.confirm_password} onChange={this.handleChange}/>
                </div>
                <div className="FormField">
                  <button className="FormField__Button mr-20" type="submit">Sign Up</button> <Link to="/signin" className="FormField__Link">I'm already a member</Link>
                </div>
              </form>
            </div>
          </div>
        </div>
      )
    }
    else
    {
      return(
        <Redirect to='/signin' />
      )
    }
  }
}

export default SignUp;
