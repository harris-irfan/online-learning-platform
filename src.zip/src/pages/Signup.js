import React, { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';
import SignIn from './Signin';

class SignUp extends Component {

  constructor(props) {
      super([props]);

      this.state = {
          email: '',
          username: '',
          first_name: '',
          last_name: '',
          password: '',
          confirm_password: ''
      };

      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(e) {
      let target = e.target;
      let value = target.value
      let name = target.name;

      this.setState({
        [name]: value
      });
  }

  handleSubmit(e) {
    e.preventDefault();

    fetch('http://127.0.0.1:8000/api/account/register', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: this.state.email,
        username: this.state.username,
        first_name: this.state.first_name,
        last_name: this.state.last_name,
        password: this.state.password,
        confirm_password: this.state.confirm_password,
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
    const response = data;

    console.log(response)

    if(response.response_code == '00'){
        console.log('success')
        return <SignIn/>
    }
    })

  }

  render() {
    return (
      <div className="FormCenter">
        <div className="FormTitle">
          Sign Up
        </div>
        <form onSubmit={this.handleSubmit} className="FormFields">
          <div className="FormField">
            <label className="FormField__Label">Email</label>
              <input type="text" name="email" value={this.state.email} onChange={this.handleChange}/>
          </div>
          <div className="FormField">
            <label className="FormField__Label">Username</label>
              <input type="text" name="username" value={this.state.username} onChange={this.handleChange}/>
          </div>
          <div className="FormField">
            <label className="FormField__Label">First Name</label>
              <input type="text" name="first_name" value={this.state.first_name} onChange={this.handleChange}/>
          </div>
          <div className="FormField">
            <label className="FormField__Label">Last Name</label>
              <input type="text" name="last_name" value={this.state.last_name} onChange={this.handleChange}/>
          </div>
          <div className="FormField">
            <label className="FormField__Label">Password</label>
              <input type="password" name="password" value={this.state.password} onChange={this.handleChange}/>
          </div>
          <div className="FormField">
            <label className="FormField__Label">Confirm Password</label>
              <input type="password" name="confirm_password" value={this.state.confirm_password} onChange={this.handleChange}/>
          </div>
          <div className="FormField">
            <button className="FormField__Button mr-20" type="submit">Sign Up</button> <Link to="/signin" className="FormField__Link">I'm already a member</Link>
          </div>
        </form>
      </div>
    )
  }
}

export default SignUp;
