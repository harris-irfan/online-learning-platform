import React, { Component } from "react";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input,
} from "reactstrap";

export default class VideoModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      title: '',
      type: '',
      weightage:'',
      course_id: this.props.course_id
    }
  }

  handleChange = e => {
    let { name, value } = e.target;
    if (name === 'title') {
      this.setState({ title: value });
    }
    else if (name === 'type'){
      this.setState({ type: value });
    }
    else if (name === 'weightage') {
      this.setState({ weightage: value });
    }
  }

  onSave = () => {
    this.props.toggle();

    const self = this

    let url = 'http://localhost:8000/api/course_modules/assessment/add/?course_id='+this.state.course_id

    fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('auth'),
      },
      body: JSON.stringify({
        title: this.state.title,
        type: 'assessment',
        assessment_type: this.state.type,
        weightage: this.state.weightage
      })
    }).then(function(response){ return response.json(); })
    .then(function(data) {
      console.log(data)
      self.props.refreshList()
    })

  }

  render() {
    const { toggle } = this.props;
    return (
      <Modal isOpen={true} toggle={toggle} className="ModuleModal">
        <ModalHeader toggle={toggle} className="ModuleModalHeader"> Add Assessment </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="title">Title</Label>
              <Input
                type="text"
                name="title"
                value={this.state.title}
                onChange={this.handleChange}
                placeholder="Enter Title"
                />
            </FormGroup>
            <FormGroup>
              <Label for="type">Type</Label>
              <br/>
              <select name='type' placeholder="Select type" onChange={this.handleChange} className="Dropdown">
                <option default>Select type</option>
                <option value="Quiz"> Quiz</option>
                <option value="Mid exam">Mid exam</option>
                <option value="Final exam">Final exam</option>
              </select>
            </FormGroup>
            <FormGroup>
              <Label for="weightage">Weightage</Label>
              <Input
                type="text"
                name="weightage"
                value={this.state.weightage}
                onChange={this.handleChange}
                placeholder="Enter weightage"
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="success" onClick={() => this.onSave()}>
            Save
          </Button>
        </ModalFooter>
      </Modal>
      );
  }
}
