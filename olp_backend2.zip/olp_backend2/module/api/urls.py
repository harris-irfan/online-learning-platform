from django.urls import path, include
from module.api.views import(
    module_view
)

app_name = 'module'

urlpatterns = [
    path('', module_view, name='view_modules')
]
