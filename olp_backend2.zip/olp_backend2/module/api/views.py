from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.core import serializers
from django.http import HttpResponse

from module.models import Module


@api_view(['GET',])
@permission_classes((IsAuthenticated, ))
def module_view(request):
    data = {}
    if request.user.is_staff or Enrollment.objects.filter(course_id = request.GET['course_id'], student_id = request.user.id).exists():
        module_queryset = Module.objects.filter(course=request.GET['course_id'])
        data = serializers.serialize('json', module_queryset)
        return HttpResponse(data, content_type="application/json")
    else:
        data['response_code'] = 403
        data['response_msg'] = 'You do not have permission to perform this action.'
    return Response(data)
