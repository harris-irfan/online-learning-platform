from django.db import models

from course.models import Course


class Module(models.Model):
    course = models.ForeignKey(
        'course.Course',
        on_delete = models.CASCADE
    )
    order = models.IntegerField()
    next_module = models.ForeignKey(
        'module.Module',
        null = True,
        on_delete = models.DO_NOTHING,
        related_name = '+'
    )
    prev_module = models.ForeignKey(
        'module.Module',
        null = True,
        on_delete = models.DO_NOTHING,
        related_name = '+'
    )

    def save(self):
        if not course.first_module:
            self.order = 1
            super(Module, self).save()
            course.first_module = self
            course.last_module = self
        else:
            self.order = course.last_module.order + 1
            super(Module, self).save()
            course.last_module.next_module = self
            course.last_module = self

    def delete(self):
        if self.is_first_module():
            if self.is_last_module():
                course.first_module = None
                course.last_module = None
            else:
                course.first_module = self.next_module
        else:
            self.prev_module.next_module = self.next_module
            if self.is_last_module():
                course.last_module = self.prev_module

        super(Module, self).delete()

    def is_first_module(self):
        if not self.prev_module:
            return True
        return False

    def is_last_module(self):
        if not self.next_module:
            return True
        return False
