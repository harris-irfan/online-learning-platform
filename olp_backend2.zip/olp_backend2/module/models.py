from django.db import models

from course.models import Course


class Module(models.Model):
    course = models.ForeignKey(
        'course.Course',
        on_delete = models.CASCADE
    )
    order = models.IntegerField()
    next_module = models.ForeignKey(
        'module.Module',
        null = True,
        # on_delete = models.DO_NOTHING,
        on_delete = models.SET_NULL,
        related_name = '+'
    )
    prev_module = models.ForeignKey(
        'module.Module',
        null = True,
        # on_delete = models.DO_NOTHING,
        on_delete = models.SET_NULL,
        related_name = '+'
    )

    def save(self):
        if not self.course.first_module:
            self.order = 1
            super(Module, self).save()
            course = Course.objects.get(id=self.course.id)
            course.first_module = self
            course.last_module = self
            course.save()
        else:
            self.order = self.course.last_module.order + 1
            self.prev_module = self.course.last_module
            self.prev_module.next_module = self
            self.course.last_module = self
            super(Module, self).save()
            super(Module, self.prev_module).save()
            self.course.save()

    def delete(self):
        if self.is_first_module():
            super(Module, self).delete()
            if self.is_last_module():
                self.course.first_module = None
                self.course.last_module = None
            else:
                self.course.first_module = self.next_module
            self.course.save()
        else:
            super(Module, self).delete()
            self.prev_module.next_module = self.next_module
            self.prev_module.save()
            if self.is_last_module():
                print('last_module')
                self.course.last_module = self.prev_module
                self.course.save()

    def is_first_module(self):
        if not self.prev_module:
            return True
        return False

    def is_last_module(self):
        if not self.next_module:
            return True
        return False
