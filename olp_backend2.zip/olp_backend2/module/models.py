from django.db import models


class Module(models.Model):
    next_module_id = models.ForeignKey(
        'module.Module',
        null = True,
        on_delete = models.SET_NULL
    )

    # class Meta:
    #     abstract = True
