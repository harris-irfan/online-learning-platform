from rest_framework import serializers

from question.models import Question
from assessment.models import Assessment

class QuestionSerializer(serializers.ModelSerializer):

    class Meta:
        model = Question
        fields = ['text']

    def save(self, assessment_id):
        question = Question(
            text = self.validated_data['text'],
            )
        question.assessment = Assessment.objects.get(id = assessment_id)
        question.save()
        return question
