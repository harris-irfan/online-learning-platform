from django.urls import path, include
from question.api.views import(
    question_view,
    submit_view,
    add_question_view,
    delete_question_view
)

app_name = 'question'

urlpatterns = [
        path('', question_view, name='questions'),
        path('submit/', submit_view, name='submit_quiz'),
        path('add/', add_question_view, name='add_question'),
        path('delete/', delete_question_view, name='delete_question')
]
