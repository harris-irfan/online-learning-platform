from django.core.management.base import BaseCommand
from question.models import Question

class Command(BaseCommand):
    def handle(self, *args, **options):
        Question.objects.all().delete()
