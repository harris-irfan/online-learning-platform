from django.db import models


class Question(models.Model):
    text = models.CharField(max_length=1000)
    assessment_id = models.ForeignKey(
        'assessment.Assessment',
        on_delete = models.CASCADE
    )

    def __str__(self):
        return self.text
