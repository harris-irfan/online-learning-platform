from django.apps import AppConfig


class CertificationConfig(AppConfig):
    name = 'certification'
