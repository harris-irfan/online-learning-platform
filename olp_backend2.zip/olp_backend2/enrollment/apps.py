from django.apps import AppConfig


class EnrollmentConfig(AppConfig):
    name = 'enrollment'
