from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response

from .serializers import ChoiceSerializer

from choice.models import Choice


@api_view(['POST',])
@permission_classes((IsAdminUser, ))
def add_choice_view(request):
    data = {}
    serializer = ChoiceSerializer(data=request.data)
    if serializer.is_valid():
        choice = serializer.save(request.GET['question_id'])
        data['response_code'] = 00
        data['response_msg'] = 'successfully added a choice'
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_choice_view(request):
    data = {}
    Choice.objects.get(id = request.GET['choice_id']).delete()
    data['response'] = 'successfully deleted choice'
    return Response(data)
