from django.db import models

from module.models import Module


class Content(Module):
    html_path = models.CharField(max_length = 1000)
    course_id = models.ForeignKey(
        'course.Course',
        on_delete = models.CASCADE
    )
