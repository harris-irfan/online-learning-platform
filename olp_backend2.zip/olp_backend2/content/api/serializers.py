from rest_framework import serializers

from content.models import Content

from course.models import Course

class ContentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Content
        fields = ['title', 'html_path']

    def save(self, course_id):
        content = Content(
            title = self.validated_data['data'],
            html_path = self.validated_data['html_path'],
            )
        content.course = Course.objects.get(id = course_id)
        content.save(update_order=True)
        return content
