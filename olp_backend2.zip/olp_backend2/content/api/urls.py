from django.urls import path, include
from content.api.views import(
    add_content_view,
    delete_content_view,
    upload_file_view,
    FileUploadView
)

app_name = 'content'

urlpatterns = [
    path('add/', upload_file_view, name='add_content'),
    path('delete/', delete_content_view, name='delete_content'),
    path('upload/', FileUploadView.as_view(), name='file_upload')
]
