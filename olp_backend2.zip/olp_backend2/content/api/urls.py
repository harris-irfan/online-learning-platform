from django.urls import path, include
from content.api.views import(
    add_content_view,
    delete_content_view
)

app_name = 'content'

urlpatterns = [
    path('add/', add_content_view, name='add_content'),
    path('delete/', delete_content_view, name='delete_content')
]
