from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response

from .serializers import ContentSerializer

from content.models import Content


@api_view(['POST',])
@permission_classes((IsAdminUser, ))
def add_content_view(request):
    data = {}
    serializer = ContentSerializer(data=request.data)
    if serializer.is_valid():
        content = serializer.save(request.GET['course_id'])
        data['response_code'] = 00
        data['response_msg'] = 'successfully added content'
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_content_view(request):
    data = {}
    Content.objects.get(id = request.GET['content_id']).delete()
    data['response'] = 'successfully deleted content'
    return Response(data)
