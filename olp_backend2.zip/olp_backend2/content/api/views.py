from rest_framework import viewsets
from rest_framework import views
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response
from rest_framework.parsers import FileUploadParser
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.conf import settings
import os

from .serializers import ContentSerializer

from content.models import Content


@api_view(['POST',])
@permission_classes((IsAdminUser, ))
def add_content_view(request):
    data = {}
    serializer = ContentSerializer(data=request.data)
    if serializer.is_valid():
        content = serializer.save(request.GET['course_id'])
        data['response_code'] = 00
        data['response_msg'] = 'successfully added content'
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_content_view(request):
    data = {}
    Content.objects.get(id = request.GET['content_id']).delete()
    data['response'] = 'successfully deleted content'
    return Response(data)


@api_view(['POST', ])
@parser_classes((FileUploadParser, ))
def upload_file_view(request):
    file_obj = request.data['file']
    print(type(file_obj))
    return Response(status=204)

class FileUploadView(views.APIView):
    parser_classes = [FileUploadParser]
    permission_classes = [IsAdminUser]

    def post(self, request, format=None):
        file_obj = request.data['file']
        content = str(file_obj.read())
        html_start_index = content.find('<')
        html_end_index = content.rfind('>')
        html = content[html_start_index: html_end_index+1]
        pure_html = html.replace(r"\n", "").replace(r"\r", "")
        filename = file_obj.name
        cwd = os.getcwd()
        course_contents_path = cwd + '/static/course_contents/'
        course_id = request.GET['course_id']
        path = course_contents_path + '/' + str(course_id) + '/'
        if not os.path.isdir(path):
            os.mkdir(path)

        if os.path.isfile(path+filename):
            data = {}
            data['respone_code'] = 400
            data['response_msg'] = "File with this name already exists"
            return Response(data)
        else:
            with open(path+filename, 'w') as f:
                f.write(pure_html)

        return Response(status=204)
