from django.db import models

from module.models import Module


class Video(Module):
    url = models.CharField(max_length = 1000)
