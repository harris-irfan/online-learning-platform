from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response

from .serializers import VideoSerializer

from video.models import Video


@api_view(['POST',])
@permission_classes((IsAdminUser, ))
def add_video_view(request):
    data = {}
    serializer = VideoSerializer(data=request.data)
    if serializer.is_valid():
        video = serializer.save(request.GET['course_id'])
        data['response_code'] = 00
        data['response_msg'] = 'successfully added a video'
        data['video_url'] = video.url
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_video_view(request):
    data = {}
    Video.objects.get(id = request.GET['video_id']).delete()
    data['response'] = 'successfully deleted video'
    return Response(data)
