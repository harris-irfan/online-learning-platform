from django.core.validators import URLValidator
from django.core.exceptions import ValidationError
from rest_framework import serializers

from video.models import Video

from course.models import Course

class VideoSerializer(serializers.ModelSerializer):

    def validate_url(self, url):
        url_validator = URLValidator()
        try:
            url_validator(url)
        except:
            raise serializers.ValidationError("invalid url")
        return url

    class Meta:
        model = Video
        fields = ['title','url']

    def save(self, course_id):
        video = Video(url=self.validated_data['url'],
                      title=self.validated_data['title'])
        video.course = Course.objects.get(id = course_id)
        video.save(update_order=True)
        return video
