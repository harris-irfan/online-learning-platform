from django.urls import path, include
from video.api.views import(
    add_video_view,
    delete_video_view
)

app_name = 'video'

urlpatterns = [
    path('add/', add_video_view, name='add_video'),
    path('delete/', delete_video_view, name='delete_video')
]
