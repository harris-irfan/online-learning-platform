from django.contrib import admin

from .models import Score


class ScoreAdmin(admin.ModelAdmin):
    list_display = ('student_id', 'assessment_id', 'marks_obtained')


admin.site.register(Score, ScoreAdmin)
