from rest_framework import serializers

from assessment.models import Assessment

from course.models import Course

class AssessmentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Assessment
        fields = ['type', 'total_marks', 'weightage']

    def save(self, course_id):
        assessment = Assessment(
            type = self.validated_data['type'],
            total_marks = self.validated_data['total_marks'],
            weightage = self.validated_data['weightage']
            )
        assessment.course = Course.objects.get(id = course_id)
        assessment.save(update_order=True)
        return assessment
