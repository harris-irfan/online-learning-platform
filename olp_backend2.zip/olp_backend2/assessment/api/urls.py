from django.urls import path, include
from assessment.api.views import(
    add_assessment_view,
    delete_assessment_view
)

app_name = 'assessment'

urlpatterns = [
    path('add/', add_assessment_view, name='add_assessment'),
    path('delete/', delete_assessment_view, name='delete_assessment')
]
