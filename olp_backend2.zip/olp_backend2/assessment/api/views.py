from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response

from .serializers import AssessmentSerializer

from course.models import Course
from assessment.models import Assessment
from question.models import Question
from certification.models import Certification


@api_view(['GET'])
def assessment_view(request):
    data = {}
    course_id = request.GET['course_id']
    if Course.objects.filter(id=course_id).exists():
        assessment_course = Course.objects.get(id=course_id)
        queryset = Assessment.objects.filter(course=assessment_course)
        data = serializers.serialize('json', queryset)
        return HttpResponse(data, content_type="application/json")
    else:
        data['response'] = 'Course not found'
        return Response(data)


@api_view(['POST',])
@permission_classes((IsAdminUser, ))
def add_assessment_view(request):
    data = {}
    serializer = AssessmentSerializer(data=request.data)
    if serializer.is_valid():
        assessment = serializer.save(request.GET['course_id'])
        data['response_code'] = 00
        data['response_msg'] = 'successfully added an assessment'
        data['assessment_type'] = assessment.type
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_assessment_view(request):
    data = {}
    Assessment.objects.get(id = request.GET['assessment_id']).delete()
    data['response'] = 'successfully deleted assessment'
    return Response(data)


@api_view(['GET',])
@permission_classes((IsAuthenticated, ))
def attempt_assessment_view(request):
    if request.user.is_staff or Enrollment.objects.filter(course_id = request.GET['course_id'], student_id = request.user.id).exists():
        if Question.objects.filter(assessment=request.GET['assessment_id']).exists():
            question_queryset = Question.objects.filter(assessment=request.GET['assessment_id'])
            choice_queryset = Choice.objects.filter(question__in = question_queryset)
            both = list(chain(question_queryset, choice_queryset))
            data = serializers.serialize('json', both)
            return HttpResponse(data, content_type="application/json")
        else:
            data['response'] = 'No questions in the assessment'
            return Response(data)
    else:
            data['response'] = 'You do not have authorization to attempt this assessment'
            return Response(data)


@api_view(['GET',])
@permission_classes((IsAuthenticated, ))
def submit_assessment_view(request):
    if request.user.is_staff or Enrollment.objects.filter(course_id = request.GET['course_id'], student_id = request.user.id).exists():
        course_id = request.GET['course_id']
        course = Course.objects.get(id = course_id)
        choices = []
        for choice_id in request.data():
            if choice_id:
                choices.append(Choice.objects.get(id = choice_id))
            earned_score = utils.calculate_score(choices)
            earned_percentage = calculate_percentage(earned_score, total_score, weightage)
            enrollment = Enrollment.objects.filter(course_id = request.GET['course_id'], student_id = request.user.id)
            enrollment.percentage_earned += earned_percentage
            enrollment_id = enrollment.id
            if enrollment.percentage_earned >= course.passing_percentage:
                certification = Certification.create(enrollment)
                data['credential_id'] = Certification.objects.get(enrollment = enrollment_id).id
                return Response(data)
