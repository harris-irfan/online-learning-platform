def calculate_score(choices):
    score = 0
    for choice in choices:
        if choice.is_correct:
            score += 1
    return score

def calculate_percentage(earned_score, total_score, weightage):
    return (earned_score/total_score)*weightage
