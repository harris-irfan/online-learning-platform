from django.db import models

from module.models import Module

ASSESSMENT_TYPES = (
    ("Quiz", "Quiz"),
    ("Mid exam", "Mid exam"),
    ("Final exam", "Final exam"),
)

class Assessment(Module):
    type = models.CharField(max_length=10, choices=ASSESSMENT_TYPES)
    total_marks = models.IntegerField()
    weightage = models.IntegerField()
