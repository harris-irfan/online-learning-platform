from django.db import models

from module.models import Module


class Assessment(Module):
    type = models.CharField(max_length = 30)
    total_marks = models.IntegerField()
    weightage = models.IntegerField()
