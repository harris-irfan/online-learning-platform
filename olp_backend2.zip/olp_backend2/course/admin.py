from django.contrib import admin

from .models import Course


class CourseAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'description', 'duration', 'passing_percentage', 'first_module', 'last_module')

admin.site.register(Course, CourseAdmin)
