from django.shortcuts import render
from rest_framework import viewsets
from .serializers import CourseSerializer
from course.models import Course
from enrollment.models import Enrollment
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser


class CourseView(viewsets.ModelViewSet):
    serializer_class = CourseSerializer
    queryset = Course.objects.all()

@api_view(['POST',])
@permission_classes((IsAdminUser, ))
def add_course_view(request):
    data = {}
    serializer = CourseSerializer(data=request.data)
    if serializer.is_valid():
        course = serializer.save()
        data['response_code'] = "00"
        data['response_msg'] = 'successfully registered a new course'
        data['course_id'] = course.id
        data['course_name'] = course.name
    else:
        data = serializer.errors
    return Response(data)


@api_view(['DELETE',])
@permission_classes((IsAdminUser, ))
def delete_course_view(request):
    data = {}
    Course.objects.get(id = request.GET['course_id']).delete()
    data['response'] = 'successfully deleted course'
    return Response(data)


@api_view(['GET',])
def course_content_view(request):
    data = {}
    if request.user.is_staff or Enrollment.objects.filter(course_id = request.GET['course_id'], student_id = request.user.id).exists():
        if Course.objects.filter(id=request.GET['id']).exists():
            data['video_link'] = Course.objects.get(id=request.GET['id']).video_link
            data['content_html_path'] = Course.objects.get(id=request.GET['id']).content_html_path
        else:
            data['response'] = 'Course not found'
    else:
        data['response'] = 'You must be enrolled in the course to view course content.'
    return Response(data)


@api_view(['POST',])
def enrollment_view(request):
    data = {}
    requested_course = request.GET['course_id']
    if Course.objects.filter(id=requested_course).exists():
        Enrollment.create(Course.objects.get(id=requested_course), request.user)
        data['response'] = 'You are successfully enrolled to the course of ' + requested_course
    else:
        data['response'] = 'Course not found'
    return Response(data)
