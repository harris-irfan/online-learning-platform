from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator


class Course(models.Model):
    id = models.CharField(max_length=9, primary_key=True)
    name = models.CharField(max_length=120)
    description = models.CharField(max_length=1200)
    duration = models.CharField(max_length=50)
    passing_percentage = models.IntegerField(
        default = 50,
        validators = [MaxValueValidator(100), MinValueValidator(1)]
    )
    first_module = models.ForeignKey(
        'module.Module',
        # on_delete = models.DO_NOTHING,
        on_delete = models.SET_NULL,
        related_name='first_module',
        null = True
    )
    last_module = models.ForeignKey(
        'module.Module',
        # on_delete = models.DO_NOTHING,
        on_delete = models.SET_NULL,
        related_name='last_module',
        null = True
    )

    def __str__(self):
        return self.name
